# Require separate seed files
require_relative 'seeds/quotes'
require_relative 'seeds/quote_categories'