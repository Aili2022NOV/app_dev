QuoteCategory.create!(quote_id: 1, category_id: 1)
QuoteCategory.create!(quote_id: 1, category_id: 2)
QuoteCategory.create!(quote_id: 1, category_id: 3)

QuoteCategory.create!(quote_id: 2, category_id: 2)
QuoteCategory.create!(quote_id: 2, category_id: 4)
QuoteCategory.create!(quote_id: 2, category_id: 5)

QuoteCategory.create!(quote_id: 3, category_id: 3)
QuoteCategory.create!(quote_id: 3, category_id: 6)

# Associate Quote 4 with Categories 1 and 4
QuoteCategory.create!(quote_id: 4, category_id: 1)
QuoteCategory.create!(quote_id: 4, category_id: 4)

# Associate Quote 5 with Categories 2 and 5
QuoteCategory.create!(quote_id: 5, category_id: 2)
QuoteCategory.create!(quote_id: 5, category_id: 5)

# Associate Quote 6 with Categories 7 and 8
QuoteCategory.create!(quote_id: 6, category_id: 7)
QuoteCategory.create!(quote_id: 6, category_id: 8)

# For example, associate Quote 7 with Categories 1, 2, and 3
QuoteCategory.create!(quote_id: 7, category_id: 1)
QuoteCategory.create!(quote_id: 7, category_id: 2)
QuoteCategory.create!(quote_id: 7, category_id: 3)

# Associate Quote 8 with Categories 4 and 5
QuoteCategory.create!(quote_id: 8, category_id: 4)
QuoteCategory.create!(quote_id: 8, category_id: 5)

# Associate Quote 9 with Categories 6 and 7
QuoteCategory.create!(quote_id: 9, category_id: 6)
QuoteCategory.create!(quote_id: 9, category_id: 7)

# Associate Quote 10 with Categories 8 and 9
QuoteCategory.create!(quote_id: 10, category_id: 8)
QuoteCategory.create!(quote_id: 10, category_id: 9)

QuoteCategory.create!(quote_id: 11, category_id: 3)
QuoteCategory.create!(quote_id: 11, category_id: 5)
QuoteCategory.create!(quote_id: 11, category_id: 8)

# Associate Quote 12 with Categories 2, 6, and 9
QuoteCategory.create!(quote_id: 12, category_id: 2)
QuoteCategory.create!(quote_id: 12, category_id: 6)
QuoteCategory.create!(quote_id: 12, category_id: 9)

# Associate Quote 13 with Categories 1, 4, and 7
QuoteCategory.create!(quote_id: 13, category_id: 1)
QuoteCategory.create!(quote_id: 13, category_id: 4)
QuoteCategory.create!(quote_id: 13, category_id: 7)

#Associate Quote 14 with Categories 1, 2, and 3
QuoteCategory.create!(quote_id: 14, category_id: 1)
QuoteCategory.create!(quote_id: 14, category_id: 2)
QuoteCategory.create!(quote_id: 14, category_id: 3)

# Associate Quote 15 with Categories 4, 5, and 6
QuoteCategory.create!(quote_id: 15, category_id: 4)
QuoteCategory.create!(quote_id: 15, category_id: 5)
QuoteCategory.create!(quote_id: 15, category_id: 6)

# Associate Quote 16 with Categories 7, 8, and 9
QuoteCategory.create!(quote_id: 16, category_id: 7)
QuoteCategory.create!(quote_id: 16, category_id: 8)
QuoteCategory.create!(quote_id: 16, category_id: 9)

#Associate Quote 17 with Categories 1, 5, and 9
QuoteCategory.create!(quote_id: 17, category_id: 1)
QuoteCategory.create!(quote_id: 17, category_id: 5)
QuoteCategory.create!(quote_id: 17, category_id: 9)

# Associate Quote 18 with Categories 2, 6, and 7
QuoteCategory.create!(quote_id: 18, category_id: 2)
QuoteCategory.create!(quote_id: 18, category_id: 6)
QuoteCategory.create!(quote_id: 18, category_id: 7)

# Associate Quote 19 with Categories 3, 4, and 8
QuoteCategory.create!(quote_id: 19, category_id: 3)
QuoteCategory.create!(quote_id: 19, category_id: 4)
QuoteCategory.create!(quote_id: 19, category_id: 8)

# Associate Quote 20 with Categories 1, 2, and 3
QuoteCategory.create!(quote_id: 20, category_id: 1)
QuoteCategory.create!(quote_id: 20, category_id: 2)
QuoteCategory.create!(quote_id: 20, category_id: 3)

# Associate Quote 21 with Categories 4, 5, and 6
QuoteCategory.create!(quote_id: 21, category_id: 4)
QuoteCategory.create!(quote_id: 21, category_id: 5)
QuoteCategory.create!(quote_id: 21, category_id: 6)

# Associate Quote 22 with Categories 7, 8, and 9
QuoteCategory.create!(quote_id: 22, category_id: 7)
QuoteCategory.create!(quote_id: 22, category_id: 8)
QuoteCategory.create!(quote_id: 22, category_id: 9)

# Associate associate Quote 23 with Categories 1, 5, and 9
QuoteCategory.create!(quote_id: 23, category_id: 1)
QuoteCategory.create!(quote_id: 23, category_id: 5)
QuoteCategory.create!(quote_id: 23, category_id: 9)

# Associate Quote 24 with Categories 2, 6, and 7
QuoteCategory.create!(quote_id: 24, category_id: 2)
QuoteCategory.create!(quote_id: 24, category_id: 6)
QuoteCategory.create!(quote_id: 24, category_id: 7)

# Associate Quote 25 with Categories 3, 4, and 8
QuoteCategory.create!(quote_id: 25, category_id: 3)
QuoteCategory.create!(quote_id: 25, category_id: 4)
QuoteCategory.create!(quote_id: 25, category_id: 8)

# Associate associate Quote 26 with Categories 1, 2, and 3
QuoteCategory.create!(quote_id: 26, category_id: 1)
QuoteCategory.create!(quote_id: 26, category_id: 2)
QuoteCategory.create!(quote_id: 26, category_id: 3)

# Associate Quote 27 with Categories 4, 5, and 6
QuoteCategory.create!(quote_id: 27, category_id: 4)
QuoteCategory.create!(quote_id: 27, category_id: 5)
QuoteCategory.create!(quote_id: 27, category_id: 6)

# Associate Quote 28 with Categories 7, 8, and 9
QuoteCategory.create!(quote_id: 28, category_id: 7)
QuoteCategory.create!(quote_id: 28, category_id: 8)
QuoteCategory.create!(quote_id: 28, category_id: 9)

# Associate associate Quote 29 with Categories 1, 5, and 9
QuoteCategory.create!(quote_id: 29, category_id: 1)
QuoteCategory.create!(quote_id: 29, category_id: 5)
QuoteCategory.create!(quote_id: 29, category_id: 9)

# Associate Quote 30 with Categories 2, 6, and 7
QuoteCategory.create!(quote_id: 30, category_id: 2)
QuoteCategory.create!(quote_id: 30, category_id: 6)
QuoteCategory.create!(quote_id: 30, category_id: 7)
