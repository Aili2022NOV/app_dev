# 1. Philosophy
Category.create!(cat_name: 'Philosophy')

# 2. Science
Category.create!(cat_name: 'Science')

# 3. Politics
Category.create!(cat_name: 'Politics')

# 4. History
Category.create!(cat_name: 'History')

# 5. Art
Category.create!(cat_name: 'Art')

# 6. Religion
Category.create!(cat_name: 'Religion')

# 7. Technology
Category.create!(cat_name: 'Technology')

# 8. Ethics
Category.create!(cat_name: 'Ethics')

# 9. Education
Category.create!(cat_name: 'Education')

# 10. Travel
Category.create!(cat_name: 'Travel')
